//
//  ViewController.swift
//  ridhaLightProject
//
//  Created by Ridha Syed on 9/24/19.
//  Copyright © 2019 Ridha Syed. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    var lightOn = true
    var colorLight=true
    @IBOutlet weak var buttonChange: UIButton!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        updateUI()

    }
    @IBAction func ridhasbutton(_ sender: Any) {
        updateUI()
        lightOn = !lightOn
    }
    
    @IBAction func buttonPressed(_ sender: Any) {
        updateUI()
        lightOn = !lightOn
    }
    
    func updateUI (){
        if lightOn {
            view.backgroundColor = .white
            
            
        } else {
            view.backgroundColor = .black
            
            
        }
        
    }
    @IBAction func rbbutton(_ sender: Any) {
        updateUI2()
        colorLight = !colorLight
    }
    func updateUI2 (){
        if colorLight {
            view.backgroundColor = .white
            
            
        } else {
            view.backgroundColor = .purple
            
            
        }
        
    }

}


